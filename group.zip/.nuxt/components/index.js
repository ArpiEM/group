export { default as Header } from '../..\\components\\Header.vue'
export { default as NavBar } from '../..\\components\\NavBar.vue'
export { default as Pagination } from '../..\\components\\Pagination.vue'
export { default as SideBar } from '../..\\components\\SideBar.vue'
export { default as AddThemeBtn } from '../..\\components\\NavBarPages\\Forum\\AddThemeBtn.vue'
export { default as ForumTable } from '../..\\components\\NavBarPages\\Forum\\ForumTable.vue'
export { default as RightSection } from '../..\\components\\NavBarPages\\Forum\\RightSection.vue'
export { default as SearchBox } from '../..\\components\\NavBarPages\\Forum\\SearchBox.vue'

export const LazyHeader = import('../..\\components\\Header.vue' /* webpackChunkName: "components_Header" */).then(c => c.default || c)
export const LazyNavBar = import('../..\\components\\NavBar.vue' /* webpackChunkName: "components_NavBar" */).then(c => c.default || c)
export const LazyPagination = import('../..\\components\\Pagination.vue' /* webpackChunkName: "components_Pagination" */).then(c => c.default || c)
export const LazySideBar = import('../..\\components\\SideBar.vue' /* webpackChunkName: "components_SideBar" */).then(c => c.default || c)
export const LazyAddThemeBtn = import('../..\\components\\NavBarPages\\Forum\\AddThemeBtn.vue' /* webpackChunkName: "components_NavBarPages/Forum/AddThemeBtn" */).then(c => c.default || c)
export const LazyForumTable = import('../..\\components\\NavBarPages\\Forum\\ForumTable.vue' /* webpackChunkName: "components_NavBarPages/Forum/ForumTable" */).then(c => c.default || c)
export const LazyRightSection = import('../..\\components\\NavBarPages\\Forum\\RightSection.vue' /* webpackChunkName: "components_NavBarPages/Forum/RightSection" */).then(c => c.default || c)
export const LazySearchBox = import('../..\\components\\NavBarPages\\Forum\\SearchBox.vue' /* webpackChunkName: "components_NavBarPages/Forum/SearchBox" */).then(c => c.default || c)
