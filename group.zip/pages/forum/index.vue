<template>
    <div class="row w-100 forumBody">
        <div class="w-100">
          <div class="mobileTitle">
            Ценообразование в строительстве
          </div>
        <div class="searchBoxContainer">
            <SearchBox class="hideOnMobile"/>
            <AddThemeBtn class="hideOnMobile onlySmallDisplays"/>
        </div>
        <ForumTable/>
        </div>
        <RightSection/>
    </div>
</template>
