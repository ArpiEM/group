<template>
    <div class="searchBox">
        <input class="searchInput" placeholder="Поиск"/>
        <img class="searchIcon" src="@/assets/icons/searchIcon.svg">
    </div>
</template>