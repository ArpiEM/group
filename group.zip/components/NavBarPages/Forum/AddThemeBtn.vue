<template>
    <div>
      <button class="createTheme">+ Создать тему</button>
    </div>
</template>

<script lang="ts">
  import Vue from 'vue'
  export default Vue.extend({

  })
</script>
<style lang="scss" scoped>
</style>
