<template>
    <div>
        <img src="@/assets/icons/triangleLeftIcon.svg" class="pointer">
        <span class="paginationNumber">1</span>
        <span class="paginationNumber">2</span>
        <span class="paginationNumber">3</span>
        <span class="paginationNumber">4</span>
        <span class="paginationNumber">5</span>
        <img src="@/assets/icons/triangleRigthIcon.svg" class="pointer">
    </div>
</template>